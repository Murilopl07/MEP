const state = {
  step: 0,
  email: "",
  projectNumber: "",
  categoryId: "",
  scores: {},
  optionalAnswers: {},
};

const STEPS = ["Identificação", "Projeto", "Categoria", "Avaliação", "Confirmação"];

const elements = {
  progressSteps: document.getElementById("progress-steps"),
  progressLabels: document.getElementById("progress-labels"),
  steps: document.querySelectorAll(".step"),
  alertBox: document.getElementById("alert-box"),
  loading: document.getElementById("loading"),
};

function showAlert(message, type = "error") {
  elements.alertBox.className = `alert alert--${type}`;
  elements.alertBox.textContent = message;
  elements.alertBox.hidden = false;
  elements.alertBox.scrollIntoView({ behavior: "smooth", block: "nearest" });
}

function hideAlert() {
  elements.alertBox.hidden = true;
}

function isValidEmail(email) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
}

function updateProgress() {
  const progressIndex = Math.min(state.step, STEPS.length - 1);

  elements.progressSteps.querySelectorAll(".progress__step").forEach((el, i) => {
    el.classList.remove("active", "done");
    if (state.step >= STEPS.length) {
      el.classList.add("done");
    } else {
      if (i < progressIndex) el.classList.add("done");
      if (i === progressIndex) el.classList.add("active");
    }
  });

  elements.progressLabels.querySelectorAll("span").forEach((el, i) => {
    el.classList.toggle("active", i === progressIndex && state.step < STEPS.length);
  });
}

function goToStep(index) {
  hideAlert();
  state.step = index;
  elements.steps.forEach((el, i) => {
    el.classList.toggle("active", i === index);
  });
  updateProgress();
  window.scrollTo({ top: 0, behavior: "smooth" });
}

function getCategory() {
  return CATEGORIES[state.categoryId];
}

function calculateAverage() {
  const category = getCategory();
  if (!category) return { average: 0, counted: 0, total: 0 };

  const scoredCriteria = category.criteria.filter((c) => c.scored);
  const validScores = scoredCriteria
    .map((c) => state.scores[c.id])
    .filter((s) => s !== undefined && s !== null && s !== 0);

  if (validScores.length === 0) return { average: 0, counted: 0, total: scoredCriteria.length };

  const sum = validScores.reduce((acc, s) => acc + s, 0);
  const average = sum / validScores.length;

  return {
    average: Math.round(average * 100) / 100,
    counted: validScores.length,
    total: scoredCriteria.length,
  };
}

function validateStep(stepIndex) {
  switch (stepIndex) {
    case 0: {
      const emailInput = document.getElementById("email");
      const emailGroup = emailInput.closest(".form-group");
      const email = emailInput.value.trim();

      emailGroup.classList.remove("has-error");

      if (!email) {
        emailGroup.classList.add("has-error");
        showAlert("Informe seu e-mail para continuar.");
        return false;
      }
      if (!isValidEmail(email)) {
        emailGroup.classList.add("has-error");
        showAlert("Informe um e-mail válido.");
        return false;
      }

      state.email = email;
      return true;
    }

    case 1: {
      const projectInput = document.getElementById("project-number");
      const projectGroup = projectInput.closest(".form-group");
      const projectNumber = projectInput.value.trim();

      projectGroup.classList.remove("has-error");

      if (!projectNumber) {
        projectGroup.classList.add("has-error");
        showAlert("Informe o número do projeto.");
        return false;
      }

      state.projectNumber = projectNumber;
      return true;
    }

    case 2: {
      if (!state.categoryId) {
        showAlert("Selecione uma categoria de avaliação.");
        return false;
      }
      return true;
    }

    case 3: {
      const category = getCategory();
      let allValid = true;
      let firstMissing = null;

      category.criteria.forEach((criterion, index) => {
        const criterionEl = document.getElementById(`criterion-${criterion.id}`);
        criterionEl.classList.remove("has-error");

        if (criterion.scored) {
          if (state.scores[criterion.id] === undefined) {
            criterionEl.classList.add("has-error");
            allValid = false;
            if (!firstMissing) firstMissing = index + 1;
          }
        } else {
          if (!state.optionalAnswers[criterion.id]) {
            criterionEl.classList.add("has-error");
            allValid = false;
            if (!firstMissing) firstMissing = index + 1;
          }
        }
      });

      if (!allValid) {
        showAlert(`Responda todos os critérios. Critério ${firstMissing} pendente.`);
        document.getElementById(`criterion-${category.criteria[firstMissing - 1].id}`)?.scrollIntoView({
          behavior: "smooth",
          block: "center",
        });
        return false;
      }

      renderSummary();
      return true;
    }

    default:
      return true;
  }
}

function renderCategorySelection() {
  const container = document.getElementById("category-grid");
  container.innerHTML = "";

  Object.values(CATEGORIES).forEach((cat) => {
    const scoredCount = cat.criteria.filter((c) => c.scored).length;
    const btn = document.createElement("button");
    btn.type = "button";
    btn.className = `category-card${state.categoryId === cat.id ? " selected" : ""}`;
    btn.innerHTML = `
      <div class="category-card__name">${cat.name}</div>
      <div class="category-card__count">${scoredCount} critérios avaliados</div>
    `;
    btn.addEventListener("click", () => {
      state.categoryId = cat.id;
      state.scores = {};
      state.optionalAnswers = {};
      container.querySelectorAll(".category-card").forEach((c) => c.classList.remove("selected"));
      btn.classList.add("selected");
      hideAlert();
    });
    container.appendChild(btn);
  });
}

function renderEvaluationForm() {
  const category = getCategory();
  const container = document.getElementById("evaluation-form");
  const titleEl = document.getElementById("evaluation-category-name");

  titleEl.textContent = category.name;
  container.innerHTML = "";

  category.criteria.forEach((criterion, index) => {
    const div = document.createElement("div");
    div.id = `criterion-${criterion.id}`;
    div.className = `criterion${criterion.scored ? "" : " criterion--optional"}`;

    let optionsHtml = "";

    if (criterion.scored) {
      optionsHtml = `<div class="score-options">`;
      SCORE_OPTIONS.forEach((opt) => {
        const checked = state.scores[criterion.id] === opt.value ? "checked" : "";
        const selected = state.scores[criterion.id] === opt.value ? " selected" : "";
        optionsHtml += `
          <label class="score-option${selected}" data-value="${opt.value}">
            <input type="radio" name="score-${criterion.id}" value="${opt.value}" ${checked} />
            <div class="score-option__content">
              <span class="score-option__label">${opt.label}</span>
              <span class="score-option__desc">${opt.description}</span>
            </div>
          </label>
        `;
      });
      optionsHtml += `</div>`;
    } else {
      optionsHtml = `<div class="simple-options">`;
      criterion.options.forEach((opt) => {
        const checked = state.optionalAnswers[criterion.id] === opt.value ? "checked" : "";
        optionsHtml += `
          <div class="simple-option">
            <input type="radio" name="optional-${criterion.id}" id="opt-${criterion.id}-${opt.value}" value="${opt.value}" ${checked} />
            <label for="opt-${criterion.id}-${opt.value}">${opt.label}</label>
          </div>
        `;
      });
      optionsHtml += `</div>`;
    }

    div.innerHTML = `
      <div class="criterion__number">${index + 1}</div>
      <h3 class="criterion__title">
        ${criterion.title}
        ${!criterion.scored ? '<span class="criterion__badge">Opcional</span>' : ""}
      </h3>
      <p class="criterion__question">${criterion.question}</p>
      ${optionsHtml}
    `;

    if (criterion.scored) {
      div.querySelectorAll(".score-option").forEach((label) => {
        label.addEventListener("click", () => {
          const value = parseInt(label.dataset.value, 10);
          state.scores[criterion.id] = value;
          div.classList.remove("has-error");
          div.querySelectorAll(".score-option").forEach((l) => l.classList.remove("selected"));
          label.classList.add("selected");
          label.querySelector("input").checked = true;
        });
      });
    } else {
      div.querySelectorAll('input[type="radio"]').forEach((input) => {
        input.addEventListener("change", () => {
          state.optionalAnswers[criterion.id] = input.value;
          div.classList.remove("has-error");
        });
      });
    }

    container.appendChild(div);
  });
}

function renderSummary() {
  const category = getCategory();
  const { average, counted, total } = calculateAverage();

  document.getElementById("summary-email").textContent = state.email;
  document.getElementById("summary-project").textContent = state.projectNumber;
  document.getElementById("summary-category").textContent = category.name;
  document.getElementById("summary-average").textContent = average.toFixed(2).replace(".", ",");
  document.getElementById("summary-counted").textContent =
    `${counted} de ${total} critérios considerados na média (notas "Não se aplica" são excluídas)`;

  const detailsContainer = document.getElementById("summary-details");
  detailsContainer.innerHTML = "";

  category.criteria.forEach((criterion) => {
    let valueText;

    if (criterion.scored) {
      const score = state.scores[criterion.id];
      if (score === 0) {
        valueText = "N/A";
      } else {
        valueText = score.toFixed(1).replace(".", ",");
      }
    } else {
      const answer = state.optionalAnswers[criterion.id];
      const opt = criterion.options.find((o) => o.value === answer);
      valueText = opt ? opt.label : "—";
    }

    const item = document.createElement("div");
    item.className = "summary-item";
    item.innerHTML = `
      <span class="summary-item__label">${criterion.title}</span>
      <span class="summary-item__value">${valueText}</span>
    `;
    detailsContainer.appendChild(item);
  });
}

function buildPayload() {
  const category = getCategory();
  const { average, counted, total } = calculateAverage();
  const timestamp = new Date().toISOString();

  const criteriaResults = category.criteria.map((criterion) => {
    const result = {
      id: criterion.id,
      title: criterion.title,
      scored: criterion.scored,
    };

    if (criterion.scored) {
      result.score = state.scores[criterion.id];
      result.excludedFromAverage = state.scores[criterion.id] === 0;
    } else {
      result.answer = state.optionalAnswers[criterion.id];
    }

    return result;
  });

  return {
    timestamp,
    avaliador: {
      email: state.email,
    },
    projeto: {
      numero: state.projectNumber,
      categoria: category.name,
      categoriaId: category.id,
    },
    avaliacao: {
      criterios: criteriaResults,
      media: average,
      criteriosConsiderados: counted,
      criteriosTotal: total,
    },
  };
}

async function submitEvaluation() {
  const payload = buildPayload();
  const webhookUrl = CONFIG.N8N_WEBHOOK_URL;

  if (webhookUrl.includes("SEU-N8N")) {
    showAlert(
      "Configure a URL do webhook n8n em js/config.js antes de enviar.",
      "error"
    );
    return;
  }

  hideAlert();
  elements.loading.classList.add("active");
  document.getElementById("btn-submit").disabled = true;

  try {
    const response = await fetch(webhookUrl, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    });

    if (!response.ok) {
      throw new Error(`Erro HTTP ${response.status}`);
    }

    document.getElementById("success-average").textContent =
      payload.avaliacao.media.toFixed(2).replace(".", ",");
    goToStep(5);
  } catch (error) {
    showAlert(
      `Falha ao enviar avaliação: ${error.message}. Verifique a conexão e a URL do n8n.`,
      "error"
    );
  } finally {
    elements.loading.classList.remove("active");
    document.getElementById("btn-submit").disabled = false;
  }
}

function resetApp() {
  state.step = 0;
  state.email = "";
  state.projectNumber = "";
  state.categoryId = "";
  state.scores = {};
  state.optionalAnswers = {};

  document.getElementById("email").value = "";
  document.getElementById("project-number").value = "";

  goToStep(0);
}

function initProgress() {
  elements.progressSteps.innerHTML = STEPS.map(
    () => `<li class="progress__step"></li>`
  ).join("");

  elements.progressLabels.innerHTML = STEPS.map(
    (label, i) => `<span${i === 0 ? ' class="active"' : ""}>${label}</span>`
  ).join("");
}

function initEventListeners() {
  document.getElementById("btn-step0-next").addEventListener("click", () => {
    if (validateStep(0)) goToStep(1);
  });

  document.getElementById("btn-step1-back").addEventListener("click", () => goToStep(0));
  document.getElementById("btn-step1-next").addEventListener("click", () => {
    if (validateStep(1)) {
      renderCategorySelection();
      goToStep(2);
    }
  });

  document.getElementById("btn-step2-back").addEventListener("click", () => goToStep(1));
  document.getElementById("btn-step2-next").addEventListener("click", () => {
    if (validateStep(2)) {
      renderEvaluationForm();
      goToStep(3);
    }
  });

  document.getElementById("btn-step3-back").addEventListener("click", () => goToStep(2));
  document.getElementById("btn-step3-next").addEventListener("click", () => {
    if (validateStep(3)) goToStep(4);
  });

  document.getElementById("btn-step4-back").addEventListener("click", () => goToStep(3));
  document.getElementById("btn-submit").addEventListener("click", submitEvaluation);
  document.getElementById("btn-new-evaluation").addEventListener("click", resetApp);

  document.getElementById("email").addEventListener("keydown", (e) => {
    if (e.key === "Enter") document.getElementById("btn-step0-next").click();
  });

  document.getElementById("project-number").addEventListener("keydown", (e) => {
    if (e.key === "Enter") document.getElementById("btn-step1-next").click();
  });
}

document.addEventListener("DOMContentLoaded", () => {
  initProgress();
  initEventListeners();
  updateProgress();
});
