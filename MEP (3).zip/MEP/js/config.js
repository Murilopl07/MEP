const CONFIG = {
  // Substitua pela URL do webhook do n8n
  N8N_WEBHOOK_URL: "http://localhost:5678/webhook-test/mep-avaliacao",
};
