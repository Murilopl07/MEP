const SCORE_OPTIONS = [
  {
    value: 0,
    label: "0,0 — Não se aplica",
    description:
      "Este critério de avaliação não é pertinente ou aplicável ao formato, escopo ou natureza específica do projeto apresentado. A atribuição desta nota não deve impactar a média final do projeto.",
  },
  {
    value: 5,
    label: "5,0 — Abaixo do Esperado",
    description:
      "Participou da Mostra sem grandes interesses. O projeto atende minimamente aos requisitos de participação, mas demonstra pouco esforço, engajamento ou profundidade na pesquisa e apresentação.",
  },
  {
    value: 6,
    label: "6,0 — Participação Básica e Esforço Inicial",
    description:
      "O projeto cumpre os requisitos básicos. Há evidência de algum esforço na coleta de informações e na apresentação, mas a compreensão do tema ou a metodologia são superficiais.",
  },
  {
    value: 7,
    label: "7,0 — Satisfatório",
    description:
      "Atende às Expectativas. O projeto é sólido, demonstrando que o estudante compreendeu o tema e aplicou uma metodologia adequada. A apresentação é clara e organizada, atendendo às expectativas para o nível educacional.",
  },
  {
    value: 8,
    label: "8,0 — Bom",
    description:
      "Supera Ligeiramente as Expectativas. O projeto é bem executado, com clareza na definição do problema e nos objetivos. O estudante demonstra bom domínio do tema e a apresentação inclui elementos visuais ou orais de qualidade.",
  },
  {
    value: 9,
    label: "9,0 — Muito Bom",
    description:
      "Excelente Execução e Profundidade. O projeto se destaca pela profundidade da pesquisa, rigor metodológico e análise crítica dos resultados. O estudante demonstra um domínio notável do tema e a apresentação é envolvente e muito bem estruturada.",
  },
  {
    value: 10,
    label: "10,0 — Excelente",
    description:
      "Trabalho Excepcional e Inovador. O projeto é exemplar, apresentando uma ideia inovadora, execução impecável e contribuições significativas. O estudante demonstra total maestria sobre o tema, e a apresentação é inspiradora, com potencial de impacto.",
  },
];

const CATEGORIES = {
  inovacao: {
    id: "inovacao",
    name: "Inovação Tecnológica",
    criteria: [
      {
        id: "relevancia",
        title: "Relevância e contexto do problema",
        question:
          "O problema abordado é pertinente, atual e demonstra compreensão do contexto científico, tecnológico ou social em que o projeto se insere?",
        scored: true,
      },
      {
        id: "definicao",
        title: "Definição do problema e objetivos",
        question:
          "O problema está claramente definido, com hipóteses e objetivos coerentes, mensuráveis e alcançáveis?",
        scored: true,
      },
      {
        id: "metodologia",
        title: "Metodologia",
        question:
          "O desenho metodológico é adequado para responder aos objetivos, controla variáveis relevantes e é descrito com precisão e clareza?",
        scored: true,
      },
      {
        id: "fontes",
        title: "Fontes de dados e referências",
        question:
          "A pesquisa apresenta fontes de informação – bibliográficas, entrevistas e outras formas de coleta de dados – que embasam teoricamente o trabalho?",
        scored: true,
      },
      {
        id: "resultados",
        title: "Resultados e análise",
        question:
          "Os resultados são apresentados de forma clara (tabelas, gráficos ou textos), são interpretados com base nas evidências e se relacionam com a hipótese ou perguntas iniciais?",
        scored: true,
      },
      {
        id: "consideracoes",
        title: "Considerações finais",
        question:
          "As considerações derivam dos resultados obtidos, refletem pensamento crítico e consideram a aplicabilidade ou continuidade do trabalho?",
        scored: true,
      },
      {
        id: "qualidade",
        title: "Qualidade científica e originalidade do trabalho",
        question:
          "O projeto apresenta uma ideia inovadora, fundamentada em conhecimentos científicos com uma abordagem rigorosa e coerente?",
        scored: true,
      },
      {
        id: "desenvoltura",
        title: "Desenvoltura, respostas e engajamento dos autores",
        question:
          "O(a) ou os(as) autores(as) demonstram domínio e envolvimento com o tema?",
        scored: true,
      },
      {
        id: "caderno_campo",
        title: "Possui caderno de campo e/ou relatório?",
        question:
          "Avaliador, este não é um item obrigatório — apenas mencione se tem ou não tem.",
        scored: false,
        options: [
          { value: "sim", label: "Sim, possui" },
          { value: "nao", label: "Não possui" },
          { value: "nao_verificado", label: "Não verificado / não mencionado" },
        ],
      },
    ],
  },
  sapz: {
    id: "sapz",
    name: "Avaliação SAPZ",
    criteria: [
      {
        id: "contextualizacao",
        title: "Apresentação da contextualização e desafio",
        question:
          "O desafio está claramente definido, com objetivos coerentes, mensuráveis e alcançáveis?",
        scored: true,
      },
      {
        id: "metodologia",
        title: "Metodologia e estratégias",
        question:
          "Os alunos apresentaram a estratégia utilizada para o desafio de aprendizagem com precisão e clareza?",
        scored: true,
      },
      {
        id: "resultados",
        title: "Resultados",
        question:
          "Os resultados são bem elaborados e apresentados, sejam eles um protótipo, um banner, uma apresentação digital ou outra produção? Relacionam-se com o desafio de aprendizagem?",
        scored: true,
      },
      {
        id: "industria",
        title: "Relação com a indústria",
        question:
          "É possível identificar o desafio na sua relação com a realidade da indústria?",
        scored: true,
      },
      {
        id: "recursos",
        title: "Recursos educacionais",
        question:
          "É possível identificar os recursos – máquinas, equipamentos, materiais utilizados no trabalho desenvolvido?",
        scored: true,
      },
      {
        id: "percepcao",
        title: "Percepção do estágio de desenvolvimento",
        question:
          "Os alunos percebem a importância do seu aprendizado dentro do curso como um todo?",
        scored: true,
      },
      {
        id: "desenvoltura_desafio",
        title: "Desenvoltura e engajamento — desafio",
        question:
          "O(a) ou os(as) autores(as) demonstram domínio e envolvimento com o desafio?",
        scored: true,
      },
      {
        id: "desenvoltura_tema",
        title: "Desenvoltura e engajamento — tema",
        question:
          "O(a) ou os(as) autores(as) demonstram domínio e envolvimento com o tema?",
        scored: true,
      },
    ],
  },
  industrial: {
    id: "industrial",
    name: "Solução Industrial (Projeto Integrador)",
    criteria: [
      {
        id: "contextualizacao",
        title: "Apresentação da contextualização e desafio",
        question:
          "O desafio está claramente definido, com objetivos coerentes, mensuráveis e alcançáveis?",
        scored: true,
      },
      {
        id: "metodologia",
        title: "Metodologia",
        question:
          "Os alunos apresentaram a estratégia/metodologia utilizada com precisão e clareza?",
        scored: true,
      },
      {
        id: "prototipo",
        title: "Qualidade do protótipo",
        question:
          "O protótipo ou solução apresentada demonstra qualidade técnica, funcionalidade e cuidado na execução?",
        scored: true,
      },
      {
        id: "aplicabilidade",
        title: "Aplicabilidade e benefícios do projeto",
        question:
          "O projeto demonstra aplicabilidade prática e benefícios claros para a indústria ou contexto de aplicação?",
        scored: true,
      },
      {
        id: "diferencial",
        title: "Diferencial da solução",
        question:
          "A solução apresenta diferenciais claros em relação a alternativas existentes ou abordagens convencionais?",
        scored: true,
      },
      {
        id: "desenvoltura",
        title: "Desenvoltura, respostas e engajamento dos autores",
        question:
          "O(a) ou os(as) autores(as) demonstram domínio e envolvimento com o tema?",
        scored: true,
      },
      {
        id: "resultados",
        title: "Resultados e análise",
        question:
          "Os resultados são apresentados de forma clara (tabelas, gráficos ou textos), são interpretados com base nas evidências e se relacionam com a hipótese ou perguntas iniciais?",
        scored: true,
      },
    ],
  },
};
